package com.parking.management.dto;

public class VehicleExitRequest {
    private String licensePlate;

    public VehicleExitRequest() {}

    public String getLicensePlate() { return licensePlate; }
    public void setLicensePlate(String licensePlate) { this.licensePlate = licensePlate; }
}